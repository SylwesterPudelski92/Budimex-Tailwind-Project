console.log('This text should appear in the console');
